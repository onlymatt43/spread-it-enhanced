# Spread It Connect

Ce plugin léger connecte votre site WordPress à votre application Spread It Standalone.

## Installation

1. Copiez le dossier `spread-it-connect` dans votre dossier `wp-content/plugins/`.
2. Activez le plugin dans l'admin WordPress.
3. Allez dans Réglages > Spread It.
4. Entrez l'URL de votre application déployée (ex: `https://mon-spread-it.vercel.app`).
5. Sauvegardez.

C'est tout ! Le script intelligent sera automatiquement chargé sur votre site et les boutons apparaîtront au survol des images.
